#
# Description: <Method description here>
#
require 'httparty'


prov = $evm.root['miq_provision'] || $evm.root['vm'].miq_provision
ipaddr = prov.get_option(:ip_addr)
puts "Starting method to delete IP #{ipaddr}"

def getToken
  $evm.log(:info, "IPAM Entering getToken")
  auth = {:username => $evm.object['user'], :password => $evm.object.decrypt('password')}
  url = $evm.object['url'] + $evm.object['context'] + '/user/'


  response = HTTParty.post(url, 
                     :basic_auth => auth, :verify => false)
  $evm.log(:info, "IPAM Debug URL. Auth is #{auth} <>")
  $evm.log(:info, "IPAM Debug URL. Response is #{response} <>")
  response.parsed_response["data"]["token"]
  
end


def getAddressId(token,ip)
  $evm.log(:info, "IPAM Entering getAddressId")
  response = HTTParty.get("#{$evm.object['url']}#{$evm.object['context']}/addresses/search/#{ip}/",
			:headers => { "token" => "#{token}" },
			:verify => false)
  unless response.parsed_response["data"].nil?
    return response.parsed_response["data"].first["id"]
  end
  puts "Unable to find IP address #{ip}"
end


def deleteAddress(token,ip)
  $evm.log(:info, "IPAM Entering deleteAddress")
    response = HTTParty.delete("#{$evm.object['url']}#{$evm.object['context']}/addresses/#{ip}/",
                        :headers => { "token" => "#{token}" },
                        :verify => false)
     unless response.parsed_response["data"].nil?
       puts "Deleted IP #{ip}"
     end
end





mytoken = getToken
addressId = getAddressId(mytoken,ipaddr)
deleteAddress(mytoken,addressId)
