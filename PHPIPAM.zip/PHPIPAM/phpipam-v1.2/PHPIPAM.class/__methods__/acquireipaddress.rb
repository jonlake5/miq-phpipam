#
# Description: <Method description here>
#
$evm.log(:info, "Starting PHP IPAM Integration")
require 'httparty'
#vlan = "VM Network VLAN 10"

prov = $evm.root['miq_provision']
dns_domain = $evm.object['domain']
subnet_name = prov.get_option(:vlan)
vm_target_name = prov.get_option(:vm_target_name)
fqdn = "#{vm_target_name}.#{dns_domain}"



def getToken
  $evm.log(:info, "IPAM Entering getToken")
  auth = {:username => $evm.object['user'], :password => $evm.object.decrypt('password')}
  url = $evm.object['url'] + $evm.object['context'] + '/user/'


  response = HTTParty.post(url, 
                     :basic_auth => auth, :verify => false)
  $evm.log(:info, "IPAM Debug URL. Auth is #{auth} <>")
  $evm.log(:info, "IPAM Debug URL. Response is #{response} <>")
  response.parsed_response["data"]["token"]
  
end


def getSections(token)
  $evm.log(:info, "IPAM Entering getSections")


  sections = Array.new
  response = HTTParty.get("#{$evm.object['url']}#{$evm.object['context']}/sections/",
			:headers => { "token" => "#{token}" },
			:verify => false)
  response.parsed_response["data"].each do |a|
    sections.push(a["id"])
  end
  sections
end

def getSubnets(token,sections)
  $evm.log(:info, "IPAM Entering getSubnets")
  subnets = Array.new
  sections.each do |sectionID|
    response = HTTParty.get("#{$evm.object['url']}#{$evm.object['context']}/sections/#{sectionID}/subnets/",
                        :headers => { "token" => "#{token}" },
                        :verify => false)

    unless response.parsed_response["data"].nil?
       response.parsed_response["data"].each do |a|
         subnets.push(a["id"])
       end
    end
  end
  subnets
end





#loop through each subnet and see which one matches our vlan
def findSubnetMatch(token,vlan,subnets)
  $evm.log(:info, "IPAM Entering findSubnetMatch")
  prov = $evm.root['miq_provision']  
  subnets.each do |subnet|
  response = HTTParty.get("#{$evm.object['url']}#{$evm.object['context']}/subnets/#{subnet}/",
                        :headers => { "token" => "#{token}" },
                        :verify => false)
  unless response.parsed_response["data"].nil?
    if response.parsed_response["data"]["description"]  == vlan
      return subnet
    end
  end
  end
end

def reserveFirstAddress(token,subnet,fqdn)
  $evm.log(:info, "IPAM Entering reserveFirstAddress")
  prov = $evm.root['miq_provision']  
  ip = String.new
  response=HTTParty.get("#{$evm.object['url']}#{$evm.object['context']}/subnets/#{subnet}/first_free/",
    :headers => { "token" => "#{token}" },
    :verify => false)
  unless response.parsed_response["data"].nil?
    ip = response.parsed_response["data"]
    puts "Found IP #{response.parsed_response["data"]}"
    puts "Reserving"
    response=HTTParty.post("#{$evm.object['url']}#{$evm.object['context']}/addresses/",
      :headers => { "token" => "#{token}" },
      :verify => false,
      :query => {"ip": "#{response.parsed_response["data"]}", "subnetId": "#{subnet}", "hostname": "#{fqdn}" }
)
    puts response.parsed_response
  end
  ip
end


#Get a token to use
mytoken = getToken

#Get a list of all sections. Returns an array of all sections
sections = getSections(mytoken)

#Get array of all subnets from all sections
subnets = getSubnets(mytoken,sections)

#Get the subnetID of the subnet that matches the subnet_name from provisioning request (Description of subnet in phpipam must match the VM Network tag in Vmware)
foundSubnet = findSubnetMatch(mytoken,subnet_name,subnets)

#Reserve the IP address in phpipam
ip_addr = reserveFirstAddress(mytoken,foundSubnet,fqdn)
puts "Using #{ip_addr} to provision the VM"

#Set the provisioning template
#subnet_addr = 
#subnet_mask = 
#gateway = 

prov.set_option(:ip_addr, ip_addr)
#prov.set_option(:subnet_addr, subnet_addr)
#prov.set_option(:subnet_mask, subnet_mask)
#prov.set_option(:gateway, gateway)
prov.set_option(:dns_domain, dns_domain)
